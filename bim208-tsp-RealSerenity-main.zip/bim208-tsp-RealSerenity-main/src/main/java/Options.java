import org.kohsuke.args4j.Option;


public class Options{

    @Option(name = "-s", aliases = "--show", usage = "Show the algortihms")
    int num = -1;


}